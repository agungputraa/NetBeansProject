package projectuas;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class AdminAction extends JFrame {

    private DefaultListModel<String> postListModel;
    private JList<String> postList;
    private JButton updateButton;
    private JButton deleteButton;

    public AdminAction() {
        setTitle("Admin Actions - Wisata Bali");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Panel utama dengan layout border
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Model untuk JList
        postListModel = new DefaultListModel<>();
        postList = new JList<>(postListModel);
        JScrollPane scrollPane = new JScrollPane(postList);

        // Tombol Update dan Delete
        updateButton = new JButton("Update");
        updateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updatePost();
            }
        });

        deleteButton = new JButton("Delete");
        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                deletePost();
            }
        });

        JPanel buttonPanel = new JPanel(new GridLayout(1, 2, 10, 0));
        buttonPanel.add(updateButton);
        buttonPanel.add(deleteButton);

        panel.add(scrollPane, BorderLayout.CENTER);
        panel.add(buttonPanel, BorderLayout.SOUTH);

        // Ambil data postingan dari database
        fetchData();

        add(panel);
    }

    private void fetchData() {
        postListModel.clear();

        Connection conn = KoneksiDatabase.getConnection();
        if (conn != null) {
            try {
                String query = "SELECT id, title FROM posts";
                PreparedStatement stmt = conn.prepareStatement(query);
                ResultSet rs = stmt.executeQuery();

                while (rs.next()) {
                    int postId = rs.getInt("id");
                    String title = rs.getString("title");
                    postListModel.addElement(postId + ": " + title);
                }
            } catch (SQLException e) {
                e.printStackTrace();
            } finally {
                KoneksiDatabase.closeConnection();
            }
        }
    }

    private void updatePost() {
        int selectedIndex = postList.getSelectedIndex();
        if (selectedIndex != -1) {
            String selectedPost = postListModel.getElementAt(selectedIndex);
            int postId = Integer.parseInt(selectedPost.split(":")[0].trim());

            // Ambil data postingan dari database
            String query = "SELECT title, summary, content, image_url, additional_info FROM posts p " +
                           "JOIN post_details pd ON p.id = pd.post_id " +
                           "WHERE p.id = ?";
            Connection conn = KoneksiDatabase.getConnection();
            if (conn != null) {
                try {
                    PreparedStatement stmt = conn.prepareStatement(query);
                    stmt.setInt(1, postId);
                    ResultSet rs = stmt.executeQuery();

                    if (rs.next()) {
                        String currentTitle = rs.getString("title");
                        String currentSummary = rs.getString("summary");
                        String currentContent = rs.getString("content");
                        String currentImageURL = rs.getString("image_url");
                        String currentAdditionalInfo = rs.getString("additional_info");

                        // Tampilkan dialog untuk update
                        UpdatePostDialog dialog = new UpdatePostDialog(this, postId, currentTitle, currentSummary, currentContent, currentImageURL, currentAdditionalInfo);
                        dialog.setVisible(true);

                        // Refresh data setelah update
                        fetchData();
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                } finally {
                    KoneksiDatabase.closeConnection();
                }
            }
        } else {
            JOptionPane.showMessageDialog(this, "Silakan pilih postingan yang ingin diupdate.", "Info", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private void deletePost() {
        int selectedIndex = postList.getSelectedIndex();
        if (selectedIndex != -1) {
            String selectedPost = postListModel.getElementAt(selectedIndex);
            int postId = Integer.parseInt(selectedPost.split(":")[0].trim());

            int option = JOptionPane.showConfirmDialog(this, "Anda yakin ingin menghapus postingan ini?", "Konfirmasi Hapus", JOptionPane.YES_NO_OPTION);
            if (option == JOptionPane.YES_OPTION) {
                Connection conn = KoneksiDatabase.getConnection();
                if (conn != null) {
                    try {
                        // Hapus dari tabel post_details terlebih dahulu
                        String deleteDetailQuery = "DELETE FROM post_details WHERE post_id = ?";
                        PreparedStatement detailStmt = conn.prepareStatement(deleteDetailQuery);
                        detailStmt.setInt(1, postId);
                        detailStmt.executeUpdate();

                        // Hapus dari tabel posts
                        String deletePostQuery = "DELETE FROM posts WHERE id = ?";
                        PreparedStatement postStmt = conn.prepareStatement(deletePostQuery);
                        postStmt.setInt(1, postId);
                        int affectedRows = postStmt.executeUpdate();

                        if (affectedRows > 0) {
                            JOptionPane.showMessageDialog(this, "Postingan berhasil dihapus!");
                            fetchData(); // Refresh data setelah delete
                        } else {
                            JOptionPane.showMessageDialog(this, "Gagal menghapus postingan.", "Error", JOptionPane.ERROR_MESSAGE);
                        }
                    } catch (SQLException e) {
                        e.printStackTrace();
                    } finally {
                        KoneksiDatabase.closeConnection();
                    }
                }
            }
        } else {
            JOptionPane.showMessageDialog(this, "Silakan pilih postingan yang ingin dihapus.", "Info", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    // Dialog untuk update postingan
    private class UpdatePostDialog extends JDialog {
        private JTextField titleField;
        private JTextArea summaryArea;
        private JTextArea contentArea;
        private JTextField imageURLField;
        private JTextArea additionalInfoArea;
        private JButton saveButton;

        private int postId;

        public UpdatePostDialog(JFrame parent, int postId, String currentTitle, String currentSummary, String currentContent, String currentImageURL, String currentAdditionalInfo) {
            super(parent, "Update Postingan", true); // Modal dialog
            this.postId = postId;

            // Panel utama
            JPanel panel = new JPanel();
            panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
            panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

            // Label dan Field untuk Judul
            JLabel titleLabel = new JLabel("Judul:");
            titleField = new JTextField(currentTitle, 30);
            panel.add(titleLabel);
            panel.add(titleField);

            // Label dan Area untuk Ringkasan
            JLabel summaryLabel = new JLabel("Ringkasan:");
            summaryArea = new JTextArea(currentSummary, 3, 30);
            summaryArea.setLineWrap(true);
            summaryArea.setWrapStyleWord(true);
            JScrollPane summaryScrollPane = new JScrollPane(summaryArea);
            panel.add(summaryLabel);
            panel.add(summaryScrollPane);

            // Label dan Area untuk Isi Postingan
            JLabel contentLabel = new JLabel("Isi Postingan:");
            contentArea = new JTextArea(currentContent, 10, 30);
            contentArea.setLineWrap(true);
            contentArea.setWrapStyleWord(true);
            JScrollPane contentScrollPane = new JScrollPane(contentArea);
            panel.add(contentLabel);
            panel.add(contentScrollPane);

            // Label dan Field untuk URL Gambar
            JLabel imageURLLabel = new JLabel("URL Gambar:");
            imageURLField = new JTextField(currentImageURL, 30);
            panel.add(imageURLLabel);
            panel.add(imageURLField);

            // Label dan Area untuk Informasi Tambahan
            JLabel additionalInfoLabel = new JLabel("Informasi Tambahan:");
            additionalInfoArea = new JTextArea(currentAdditionalInfo, 3, 30);
            additionalInfoArea.setLineWrap(true);
            additionalInfoArea.setWrapStyleWord(true);
            JScrollPane additionalInfoScrollPane = new JScrollPane(additionalInfoArea);
            panel.add(additionalInfoLabel);
            panel.add(additionalInfoScrollPane);

            // Tombol Simpan
            saveButton = new JButton("Simpan");
            saveButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    saveUpdatedPost();
                }
            });
            panel.add(saveButton);

            // Setting dialog properties
            setContentPane(panel);
            setDefaultCloseOperation(DISPOSE_ON_CLOSE);
            pack();
            setLocationRelativeTo(parent);
        }

        private void saveUpdatedPost() {
            String newTitle = titleField.getText();
            String newSummary = summaryArea.getText();
            String newContent = contentArea.getText();
            String newImageURL = imageURLField.getText();
            String newAdditionalInfo = additionalInfoArea.getText();

            Connection conn = KoneksiDatabase.getConnection();
            if (conn != null) {
                try {
                    // Update tabel posts
                    String updatePostSQL = "UPDATE posts SET title = ?, summary = ?, content = ? WHERE id = ?";
                    PreparedStatement postStmt = conn.prepareStatement(updatePostSQL);
                    postStmt.setString(1, newTitle);
                    postStmt.setString(2, newSummary);
                    postStmt.setString(3, newContent);
                    postStmt.setInt(4, postId);
                    int affectedRows = postStmt.executeUpdate();

                    if (affectedRows > 0) {
                        // Update tabel post_details
                        String updateDetailSQL = "UPDATE post_details SET image_url = ?, additional_info = ? WHERE post_id = ?";
                        PreparedStatement detailStmt = conn.prepareStatement(updateDetailSQL);
                        detailStmt.setString(1, newImageURL);
                        detailStmt.setString(2, newAdditionalInfo);
                        detailStmt.setInt(3, postId);
                        detailStmt.executeUpdate();

                        JOptionPane.showMessageDialog(UpdatePostDialog.this, "Postingan berhasil diupdate!");
                        dispose(); // Tutup dialog setelah berhasil update
                    } else {
                        JOptionPane.showMessageDialog(UpdatePostDialog.this, "Gagal mengupdate postingan.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(UpdatePostDialog.this, "Gagal mengupdate postingan: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                } finally {
                    KoneksiDatabase.closeConnection();
                }
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new AdminAction().setVisible(true);
            }
        });
    }
}
