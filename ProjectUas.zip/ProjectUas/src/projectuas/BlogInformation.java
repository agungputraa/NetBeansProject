package projectuas;

import javax.swing.*;
import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class BlogInformation extends JFrame {

    public BlogInformation(int postId, String title) {
        setTitle("Blog Information - " + title);
        setSize(600, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        // Panel utama dengan layout border
        JPanel panel = new JPanel();
        panel.setBackground(new Color(41, 50, 65));
        panel.setLayout(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Panel untuk konten informasi
        JPanel contentPanel = new JPanel();
        contentPanel.setBackground(new Color(41, 50, 65));
        contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));
        contentPanel.setBorder(BorderFactory.createLineBorder(Color.WHITE));

        // Ambil data dari database
        Connection conn = KoneksiDatabase.getConnection();
        if (conn != null) {
            try {
                String query = "SELECT p.title, p.content, pd.image_url, pd.additional_info " +
                        "FROM posts p JOIN post_details pd ON p.id = pd.post_id " +
                        "WHERE p.id = ?";
                PreparedStatement stmt = conn.prepareStatement(query);
                stmt.setInt(1, postId);
                ResultSet rs = stmt.executeQuery();

                if (rs.next()) {
                    String content = rs.getString("content");
                    String imageURL = rs.getString("image_url");
                    String additionalInfo = rs.getString("additional_info");

                    // Tampilkan judul
                    JLabel titleLabel = new JLabel(title);
                    titleLabel.setForeground(Color.WHITE);
                    titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
                    titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
                    titleLabel.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0)); // Padding untuk judul
                    contentPanel.add(titleLabel);

                    // Tampilkan gambar jika tersedia
                    if (imageURL != null && !imageURL.isEmpty()) {
                        try {
                            ImageIcon imageIcon = new ImageIcon(new java.net.URL(imageURL));
                            JLabel imageLabel = new JLabel();
                            imageLabel.setIcon(new ImageIcon(imageIcon.getImage().getScaledInstance(500, 300, Image.SCALE_SMOOTH)));
                            imageLabel.setHorizontalAlignment(SwingConstants.CENTER);
                            contentPanel.add(imageLabel);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }

                    // Tampilkan isi postingan
                    JTextArea contentTextArea = new JTextArea(content);
                    contentTextArea.setEditable(false);
                    contentTextArea.setLineWrap(true);
                    contentTextArea.setWrapStyleWord(true);
                    contentTextArea.setBackground(new Color(41, 50, 65));
                    contentTextArea.setForeground(Color.WHITE);
                    contentTextArea.setFont(new Font("Arial", Font.PLAIN, 16));
                    JScrollPane scrollPane = new JScrollPane(contentTextArea);
                    scrollPane.setPreferredSize(new Dimension(500, 300));
                    contentPanel.add(scrollPane);

                    // Tampilkan informasi tambahan jika tersedia
                    if (additionalInfo != null && !additionalInfo.isEmpty()) {
                        JLabel additionalInfoLabel = new JLabel("<html><br/>Informasi Tambahan:<br/><br/>" + additionalInfo + "</html>");
                        additionalInfoLabel.setForeground(Color.WHITE);
                        additionalInfoLabel.setFont(new Font("Arial", Font.PLAIN, 14));
                        contentPanel.add(additionalInfoLabel);
                    }
                }
            } catch (SQLException e) {
                e.printStackTrace();
            } finally {
                KoneksiDatabase.closeConnection();
            }
        }

        panel.add(contentPanel, BorderLayout.CENTER);
        add(panel);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new BlogInformation(1, "Sample Title").setVisible(true);
            }
        });
    }
}
