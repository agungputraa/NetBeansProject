package projectuas;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class AdminPanel extends JFrame {

    private JTextField titleField;
    private JTextField summaryField;
    private JTextArea contentArea;
    private JTextField imageURLField;
    private JTextArea additionalInfoArea;
    private JButton saveButton;
    private JButton adminActionButton; // Tombol untuk membuka AdminAction

    public AdminPanel() {
        setTitle("Admin Panel - Wisata Bali");
        setSize(500, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setBackground(new Color(41, 50, 65));
        panel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Judul
        JLabel titleLabel = new JLabel("Judul:");
        titleLabel.setForeground(Color.WHITE);
        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(titleLabel, gbc);

        titleField = new JTextField(30);
        gbc.gridx = 1;
        gbc.gridy = 0;
        panel.add(titleField, gbc);

        // Ringkasan
        JLabel summaryLabel = new JLabel("Ringkasan:");
        summaryLabel.setForeground(Color.WHITE);
        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(summaryLabel, gbc);

        summaryField = new JTextField(30);
        gbc.gridx = 1;
        gbc.gridy = 1;
        panel.add(summaryField, gbc);

        // Isi Postingan
        JLabel contentLabel = new JLabel("Isi Postingan:");
        contentLabel.setForeground(Color.WHITE);
        gbc.gridx = 0;
        gbc.gridy = 2;
        panel.add(contentLabel, gbc);

        contentArea = new JTextArea(10, 30);
        contentArea.setLineWrap(true);
        contentArea.setWrapStyleWord(true);
        JScrollPane contentScrollPane = new JScrollPane(contentArea);
        gbc.gridx = 1;
        gbc.gridy = 2;
        gbc.gridheight = 3;
        panel.add(contentScrollPane, gbc);

        // URL Gambar
        JLabel imageURLLabel = new JLabel("URL Gambar:");
        imageURLLabel.setForeground(Color.WHITE);
        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.gridheight = 1;
        panel.add(imageURLLabel, gbc);

        imageURLField = new JTextField(30);
        gbc.gridx = 1;
        gbc.gridy = 5;
        panel.add(imageURLField, gbc);

        // Informasi Tambahan
        JLabel additionalInfoLabel = new JLabel("Informasi Tambahan:");
        additionalInfoLabel.setForeground(Color.WHITE);
        gbc.gridx = 0;
        gbc.gridy = 6;
        panel.add(additionalInfoLabel, gbc);

        additionalInfoArea = new JTextArea(3, 30);
        additionalInfoArea.setLineWrap(true);
        additionalInfoArea.setWrapStyleWord(true);
        JScrollPane additionalInfoScrollPane = new JScrollPane(additionalInfoArea);
        gbc.gridx = 1;
        gbc.gridy = 6;
        panel.add(additionalInfoScrollPane, gbc);

        // Tombol Simpan
        saveButton = new JButton("Simpan");
        saveButton.setBackground(new Color(0, 0, 0));
        saveButton.setForeground(Color.BLACK);
        saveButton.setFocusPainted(false);
        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                savePost();
            }
        });
        gbc.gridx = 1;
        gbc.gridy = 7;
        gbc.anchor = GridBagConstraints.CENTER;
        panel.add(saveButton, gbc);

        // Tombol AdminAction
        adminActionButton = new JButton("Admin Action");
        adminActionButton.setBackground(new Color(0, 0, 0));
        adminActionButton.setForeground(Color.BLACK);
        adminActionButton.setFocusPainted(false);
        adminActionButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openAdminAction();
            }
        });
        gbc.gridx = 0;
        gbc.gridy = 7;
        panel.add(adminActionButton, gbc);

        getContentPane().add(panel);
    }

    private void savePost() {
        String title = titleField.getText();
        String summary = summaryField.getText();
        String content = contentArea.getText();
        String imageURL = imageURLField.getText();
        String additionalInfo = additionalInfoArea.getText();

        Connection conn = KoneksiDatabase.getConnection();
        if (conn != null) {
            try {
                // Insert into posts
                String insertPostSQL = "INSERT INTO posts (title, summary, content) VALUES (?, ?, ?)";
                PreparedStatement postStmt = conn.prepareStatement(insertPostSQL, PreparedStatement.RETURN_GENERATED_KEYS);
                postStmt.setString(1, title);
                postStmt.setString(2, summary);
                postStmt.setString(3, content);
                int affectedRows = postStmt.executeUpdate();

                if (affectedRows > 0) {
                    // Get the generated post ID
                    int postId = 0;
                    try (var rs = postStmt.getGeneratedKeys()) {
                        if (rs.next()) {
                            postId = rs.getInt(1);
                        }
                    }

                    // Insert into post_details
                    String insertDetailSQL = "INSERT INTO post_details (post_id, image_url, additional_info) VALUES (?, ?, ?)";
                    PreparedStatement detailStmt = conn.prepareStatement(insertDetailSQL);
                    detailStmt.setInt(1, postId);
                    detailStmt.setString(2, imageURL);
                    detailStmt.setString(3, additionalInfo);
                    detailStmt.executeUpdate();

                    JOptionPane.showMessageDialog(this, "Postingan berhasil disimpan!");
                    clearFields();
                }
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, "Gagal menyimpan postingan: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            } finally {
                KoneksiDatabase.closeConnection();
            }
        }
    }

    private void clearFields() {
        titleField.setText("");
        summaryField.setText("");
        contentArea.setText("");
        imageURLField.setText("");
        additionalInfoArea.setText("");
    }

    private void openAdminAction() {
        new AdminAction().setVisible(true); // Membuka AdminAction saat tombol Admin Action diklik
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                try {
                    // Apply a look and feel
                    UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
                } catch (Exception e) {
                    e.printStackTrace();
                }

                new AdminPanel().setVisible(true);
            }
        });
    }
}
