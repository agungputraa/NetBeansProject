package projectuas;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class BlogPost extends JFrame {

    private JPanel panel;
    private JScrollPane scrollPane;

    public BlogPost() {
        setTitle("Blog Post - Wisata Bali");
        setSize(900, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Panel utama dengan layout box vertical di dalam scroll pane
        panel = new JPanel();
        panel.setBackground(new Color(41, 50, 65));
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        scrollPane = new JScrollPane(panel);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

        loadPosts(); // Memuat postingan pertama kali saat aplikasi dibuka

        JButton refreshButton = new JButton("Refresh");
        refreshButton.setBackground(new Color(38, 50, 56));
        refreshButton.setForeground(Color.WHITE);
        refreshButton.setFocusPainted(false);
        refreshButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                refreshPosts();
            }
        });

        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(new Color(41, 50, 65));
        buttonPanel.add(refreshButton);

        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(scrollPane, BorderLayout.CENTER);
        getContentPane().add(buttonPanel, BorderLayout.SOUTH);
    }

    private void loadPosts() {
        // Ambil data dari database
        Connection conn = KoneksiDatabase.getConnection();
        if (conn != null) {
            try {
                String query = "SELECT p.id, p.title, p.summary, pd.image_url FROM posts p " +
                               "JOIN post_details pd ON p.id = pd.post_id";
                PreparedStatement stmt = conn.prepareStatement(query);
                ResultSet rs = stmt.executeQuery();

                panel.removeAll(); // Menghapus semua komponen di panel sebelum memuat ulang
                while (rs.next()) {
                    int postId = rs.getInt("id");
                    String title = rs.getString("title");
                    String summary = rs.getString("summary");
                    String imageURL = rs.getString("image_url");

                    // Buat panel untuk setiap postingan
                    JPanel postPanel = createPostPanel(postId, title, summary, imageURL);
                    panel.add(postPanel);
                    panel.add(Box.createRigidArea(new Dimension(0, 20))); // Spasi antar postingan
                }
                
                panel.revalidate();
                panel.repaint();

            } catch (SQLException e) {
                e.printStackTrace();
            } finally {
                KoneksiDatabase.closeConnection();
            }
        }
    }

    private JPanel createPostPanel(int postId, String title, String summary, String imageURL) {
        JPanel postPanel = new JPanel();
        postPanel.setLayout(new BorderLayout());
        postPanel.setBackground(new Color(84, 110, 122));
        postPanel.setBorder(BorderFactory.createLineBorder(Color.WHITE));
        postPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 150)); // Tinggi maksimal panel

        JLabel imageLabel = new JLabel();
        imageLabel.setPreferredSize(new Dimension(150, 150));
        imageLabel.setHorizontalAlignment(SwingConstants.CENTER);
        imageLabel.setVerticalAlignment(SwingConstants.CENTER);
        
        // Load image (dengan placeholder jika gagal)
        try {
            ImageIcon imageIcon = new ImageIcon(new java.net.URL(imageURL));
            imageLabel.setIcon(new ImageIcon(imageIcon.getImage().getScaledInstance(150, 150, Image.SCALE_SMOOTH)));
        } catch (Exception e) {
            imageLabel.setText("Gambar tidak tersedia");
            imageLabel.setHorizontalTextPosition(SwingConstants.CENTER);
            imageLabel.setVerticalTextPosition(SwingConstants.CENTER);
        }

        JPanel textPanel = new JPanel();
        textPanel.setBackground(new Color(84, 110, 122));
        textPanel.setLayout(new BoxLayout(textPanel, BoxLayout.Y_AXIS));

        JLabel titleLabel = new JLabel(title);
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 16));
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JTextArea summaryTextArea = new JTextArea(summary);
        summaryTextArea.setEditable(false);
        summaryTextArea.setLineWrap(true);
        summaryTextArea.setWrapStyleWord(true);
        summaryTextArea.setBackground(new Color(84, 110, 122));
        summaryTextArea.setForeground(Color.WHITE);
        summaryTextArea.setFont(new Font("Arial", Font.PLAIN, 14));
        summaryTextArea.setAlignmentX(Component.CENTER_ALIGNMENT);

        textPanel.add(titleLabel);
        textPanel.add(Box.createRigidArea(new Dimension(0, 5))); // Spasi antara judul dan ringkasan
        textPanel.add(summaryTextArea);

        JButton viewButton = new JButton("View");
        viewButton.setBackground(new Color(38, 50, 56));
        viewButton.setForeground(Color.WHITE);
        viewButton.setFocusPainted(false);
        viewButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        viewButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new BlogInformation(postId, title).setVisible(true);
            }
        });

        postPanel.add(imageLabel, BorderLayout.WEST);
        postPanel.add(textPanel, BorderLayout.CENTER);
        postPanel.add(viewButton, BorderLayout.EAST);

        return postPanel;
    }

    private void refreshPosts() {
        loadPosts(); // Memuat ulang data postingan dari database
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new BlogPost().setVisible(true);
            }
        });
    }
}
