/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication1;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author LPIK STIKI
 */

public class KoneksiDatabase {
    // Informasi koneksi database
    private static final String URL = "jdbc:mysql://localhost/agung";
    private static final String USER = "root";
    private static final String PASSWORD = "";

    // Metode untuk mendapatkan koneksi ke database
    public static Connection getConnection() {
        try {
            // Membuat koneksi menggunakan DriverManager
            Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
            System.out.println("Koneksi ke database berhasil.");
            return connection;
        } catch (SQLException ex) {
            // Tangani kesalahan jika gagal terkoneksi ke database
            System.out.println("Koneksi ke database gagal: " + ex.getMessage());
            return null;
        }
    }

    // Metode untuk menutup koneksi database
    public static void closeConnection(Connection connection) {
        try {
            if (connection != null) {
                connection.close();
                System.out.println("Koneksi database ditutup.");
            }
        } catch (SQLException ex) {
            // Tangani kesalahan jika gagal menutup koneksi
            System.out.println("Gagal menutup koneksi database: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        // Contoh penggunaan koneksi database
        Connection connection = getConnection();
        // Lakukan operasi database di sini
     // Jangan lupa untuk menutup koneksi setelah selesai
     //  closeConnection(connection);
    }
}

