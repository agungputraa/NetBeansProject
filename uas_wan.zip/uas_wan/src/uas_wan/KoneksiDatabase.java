/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package uas_wan;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class KoneksiDatabase {
    // Konfigurasi database
    private static final String URL = "jdbc:mysql://localhost:3306/warung";
    private static final String USER = "root"; // Ganti dengan username MySQL kamu
    private static final String PASSWORD = ""; // Ganti dengan password MySQL kamu

    // Koneksi
    private static Connection connection = null;

    // Metode untuk mendapatkan koneksi
    public static Connection getConnection() {
        if (connection == null) {
            try {
                // Memuat driver MySQL
                Class.forName("com.mysql.cj.jdbc.Driver");
                // Membangun koneksi
                connection = DriverManager.getConnection(URL, USER, PASSWORD);
                System.out.println("Koneksi ke database berhasil!");
            } catch (ClassNotFoundException e) {
                System.err.println("Driver tidak ditemukan: " + e.getMessage());
            } catch (SQLException e) {
                System.err.println("Gagal terhubung ke database: " + e.getMessage());
            }
        }
        return connection;
    }

    // Metode untuk menutup koneksi
    public static void closeConnection() {
        
    }
    
}



