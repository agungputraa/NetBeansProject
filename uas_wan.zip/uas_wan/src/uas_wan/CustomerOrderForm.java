package uas_wan;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DecimalFormat;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class CustomerOrderForm extends javax.swing.JFrame {

    private Connection connection;
    private DefaultTableModel model;
    private JTable table;
    private JComboBox<String> cbProducts;
    private JTextField tfQuantity, tfCustomerName, tfAddress, tfPhone;
    private JButton btnAddToCart, btnRemoveFromCart, btnPlaceOrder;
    private JLabel lblTotalAmount;
    private JScrollPane scrollPane;
    private double totalAmount;

    public CustomerOrderForm() {
        initComponents();
        connection = KoneksiDatabase.getConnection();
        model = new DefaultTableModel();
        table = new JTable(model);
        scrollPane = new JScrollPane(table);
        scrollPane.setBounds(20, 20, 660, 200);
        add(scrollPane);
        
        cbProducts = new JComboBox<>();
        cbProducts.setBounds(20, 240, 200, 30);
        loadProducts();
        add(cbProducts);
        
        tfQuantity = new JTextField();
        tfQuantity.setBounds(240, 240, 80, 30);
        add(tfQuantity);
        
        btnAddToCart = new JButton("Add to Cart");
        btnAddToCart.setBounds(340, 240, 150, 30);
        btnAddToCart.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                addToCartActionPerformed(evt);
            }
        });
        add(btnAddToCart);
        
        btnRemoveFromCart = new JButton("Remove from Cart");
        btnRemoveFromCart.setBounds(500, 240, 180, 30);
        btnRemoveFromCart.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                removeFromCartActionPerformed(evt);
            }
        });
        add(btnRemoveFromCart);
        
        btnPlaceOrder = new JButton("Place Order");
        btnPlaceOrder.setBounds(20, 280, 150, 30);
        btnPlaceOrder.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                placeOrderActionPerformed(evt);
            }
        });
        add(btnPlaceOrder);
        
        lblTotalAmount = new JLabel("Total Amount: Rp 0,00");
        lblTotalAmount.setBounds(200, 280, 200, 30);
        add(lblTotalAmount);
        
        // Components for customer information
        JLabel lblCustomerName = new JLabel("Customer Name:");
        lblCustomerName.setBounds(20, 320, 100, 30);
        add(lblCustomerName);
        
        tfCustomerName = new JTextField();
        tfCustomerName.setBounds(130, 320, 150, 30);
        add(tfCustomerName);
        
        JLabel lblAddress = new JLabel("Address:");
        lblAddress.setBounds(300, 320, 60, 30);
        add(lblAddress);
        
        tfAddress = new JTextField();
        tfAddress.setBounds(370, 320, 150, 30);
        add(tfAddress);
        
        JLabel lblPhone = new JLabel("Phone:");
        lblPhone.setBounds(540, 320, 60, 30);
        add(lblPhone);
        
        tfPhone = new JTextField();
        tfPhone.setBounds(600, 320, 100, 30);
        add(tfPhone);
        
        model.addColumn("Product");
        model.addColumn("Price");
        model.addColumn("Quantity");
        model.addColumn("Subtotal");
    }

    private void initComponents() {
        setTitle("Customer Order Form");
        setLayout(null);
        setSize(700, 400); // Increased height to accommodate customer information
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
    }

    private void loadProducts() {
        try {
            String sql = "SELECT * FROM products";
            PreparedStatement ps = connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            DefaultComboBoxModel<String> model = new DefaultComboBoxModel<>();
            while (rs.next()) {
                int productId = rs.getInt("product_id");
                String productName = rs.getString("product_name");
                double price = rs.getDouble("price");
                String formattedPrice = formatRupiah(price);
                model.addElement(productName + " - " + formattedPrice);
            }
            cbProducts.setModel(model);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Failed to load products: " + e.getMessage());
        }
    }

    private String formatRupiah(double harga) {
        DecimalFormat df = new DecimalFormat("#,###,###.00");
        return "Rp " + df.format(harga);
    }

    private void addToCartActionPerformed(ActionEvent evt) {
        String selectedProduct = (String) cbProducts.getSelectedItem();
        String[] parts = selectedProduct.split(" - ");
        String productName = parts[0];
        String priceString = parts[1].replace("Rp ", "").replace(".", "").replace(",", ".");
        double price = Double.parseDouble(priceString);
        
        try {
            int quantity = Integer.parseInt(tfQuantity.getText());
            double subtotal = price * quantity;
            model.addRow(new Object[]{productName, formatRupiah(price), quantity, formatRupiah(subtotal)});
            totalAmount += subtotal;
            lblTotalAmount.setText("Total Amount: " + formatRupiah(totalAmount));
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Invalid quantity. Please enter a valid number.");
        }
    }
    
    private void removeFromCartActionPerformed(ActionEvent evt) {
        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Select a row to remove.");
            return;
        }
        
        String subtotalString = (String) model.getValueAt(selectedRow, 3);
        double subtotal = parseRupiah(subtotalString);
        totalAmount -= subtotal;
        lblTotalAmount.setText("Total Amount: " + formatRupiah(totalAmount));
        
        model.removeRow(selectedRow);
    }
    
    private double parseRupiah(String rupiah) {
        // Remove currency symbol and thousand separators
        String cleanString = rupiah.replace("Rp ", "").replace(".", "").replace(",", ".");
        return Double.parseDouble(cleanString);
    }
    
    private void placeOrderActionPerformed(ActionEvent evt) {
        String customerName = tfCustomerName.getText().trim();
        String address = tfAddress.getText().trim();
        String phone = tfPhone.getText().trim();
        
        if (customerName.isEmpty() || address.isEmpty() || phone.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please complete customer information.");
            return;
        }
        
        try {
            // Insert into customers table
            String insertCustomerSQL = "INSERT INTO customers (name, address, phone) VALUES (?, ?, ?)";
            PreparedStatement ps = connection.prepareStatement(insertCustomerSQL, PreparedStatement.RETURN_GENERATED_KEYS);
            ps.setString(1, customerName);
            ps.setString(2, address);
            ps.setString(3, phone);
            int customerAffectedRows = ps.executeUpdate();
            if (customerAffectedRows == 0) {
                throw new SQLException("Creating customer failed, no rows affected.");
            }
            
            // Get the generated customer_id
            ResultSet generatedCustomerKeys = ps.getGeneratedKeys();
            int customerId;
            if (generatedCustomerKeys.next()) {
                customerId = generatedCustomerKeys.getInt(1);
            } else {
                throw new SQLException("Creating customer failed, no ID obtained.");
            }
            
            // Insert into orders table
            String insertOrderSQL = "INSERT INTO orders (customer_id, order_date, total_amount) VALUES (?, CURDATE(), ?)";
            ps = connection.prepareStatement(insertOrderSQL, PreparedStatement.RETURN_GENERATED_KEYS);
            ps.setInt(1, customerId);
            ps.setDouble(2, totalAmount);
            int orderAffectedRows = ps.executeUpdate();
            if (orderAffectedRows == 0) {
                throw new SQLException("Creating order failed, no rows affected.");
            }
            
            // Get the generated order_id
            ResultSet generatedOrderKeys = ps.getGeneratedKeys();
            int orderId;
            if (generatedOrderKeys.next()) {
                orderId = generatedOrderKeys.getInt(1);
            } else {
                throw new SQLException("Creating order failed, no ID obtained.");
            }
            
            // Insert into order_items table
            for (int i = 0; i < model.getRowCount(); i++) {
                String productName = (String) model.getValueAt(i, 0);
                int quantity = (int) model.getValueAt(i, 2);
                String subtotalString = (String) model.getValueAt(i, 3);
                double subtotal = parseRupiah(subtotalString); // Parse subtotal from formatted string
                
                // Get product_id and price from products table
                String getProductSQL = "SELECT product_id, price FROM products WHERE product_name = ?";
                ps = connection.prepareStatement(getProductSQL);
                ps.setString(1, productName);
                ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    int productId = rs.getInt("product_id");
                    double price = rs.getDouble("price");
                    
                    // Insert into order_items table
                    String insertOrderItemSQL = "INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)";
                    ps = connection.prepareStatement(insertOrderItemSQL);
                    ps.setInt(1, orderId);
                    ps.setInt(2, productId);
                    ps.setInt(3, quantity);
                    ps.setDouble(4, price); // Use the price from products table
                    ps.executeUpdate();
                }
            }
            
            JOptionPane.showMessageDialog(this, "Order placed successfully!");
            
            // Reset form
            model.setRowCount(0);
            totalAmount = 0;
            lblTotalAmount.setText("Total Amount: Rp 0,00");
            tfQuantity.setText("");
            tfCustomerName.setText("");
            tfAddress.setText("");
            tfPhone.setText("");
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Failed to place order: " + e.getMessage());
        }
    }
    
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CustomerOrderForm().setVisible(true);
            }
        });
    }
}
