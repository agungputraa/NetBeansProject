package uas_wan;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class AdminPanel extends javax.swing.JFrame {

    private Connection connection;
    private DefaultTableModel model;
    private JTable table;
    private JButton btnTambah, btnHapus, btnEdit;
    private JScrollPane scrollPane;

    public AdminPanel() {
        initComponents();
        connection = KoneksiDatabase.getConnection();
        model = new DefaultTableModel();
        table = new JTable(model);
        scrollPane = new JScrollPane(table);
        scrollPane.setBounds(20, 20, 360, 300);
        add(scrollPane);
        btnTambah = new JButton("Tambah");
        btnTambah.setBounds(400, 20, 100, 30);
        btnTambah.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                tambahProdukActionPerformed(evt);
            }
        });
        add(btnTambah);
        btnEdit = new JButton("Edit");
        btnEdit.setBounds(400, 70, 100, 30);
        btnEdit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                editProdukActionPerformed(evt);
            }
        });
        add(btnEdit);
        btnHapus = new JButton("Hapus");
        btnHapus.setBounds(400, 120, 100, 30);
        btnHapus.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                hapusProdukActionPerformed(evt);
            }
        });
        add(btnHapus);
        model.addColumn("ID");
        model.addColumn("Nama Produk");
        model.addColumn("Harga");
        loadProduk();
    }

    private void initComponents() {
        setTitle("Admin Panel");
        setLayout(null);
        setSize(550, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
    }

    private void loadProduk() {
        try {
            String sql = "SELECT * FROM products";
            PreparedStatement ps = connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            
            // Menghapus semua baris dari tabel sebelum menambahkan yang baru
            model.setRowCount(0);
    
            while (rs.next()) {
                int productId = rs.getInt("product_id");
                String productName = rs.getString("product_name");
                double price = rs.getDouble("price");
                
                // Mengubah harga menjadi format rupiah
                String formattedPrice = formatRupiah(price);
    
                // Menambahkan baris ke dalam model tabel
                model.addRow(new Object[]{productId, productName, formattedPrice});
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Gagal mengambil data produk: " + e.getMessage());
        }
    }
    
    
    private String formatRupiah(double harga) {
        // Membuat format rupiah dengan pemisah ribuan dan dua digit desimal
        return String.format("Rp %,.2f", harga);
    }

    
    private void tambahProdukActionPerformed(ActionEvent evt) {
        String namaProduk = JOptionPane.showInputDialog(this, "Masukkan Nama Produk:");
        if (namaProduk != null && !namaProduk.isEmpty()) {
            try {
                String inputHarga = JOptionPane.showInputDialog(this, "Masukkan Harga Produk (tanpa titik atau koma):");
                if (inputHarga != null && !inputHarga.isEmpty()) {
                    double hargaProduk = Double.parseDouble(inputHarga);
                    String formattedHarga = formatRupiah(hargaProduk);
                    
                    int confirm = JOptionPane.showConfirmDialog(this, "Anda yakin ingin menambahkan produk dengan detail berikut?\n\nNama: " + namaProduk + "\nHarga: " + formattedHarga, "Konfirmasi", JOptionPane.YES_NO_OPTION);
                    if (confirm == JOptionPane.YES_OPTION) {
                        String sql = "INSERT INTO products (product_name, price) VALUES (?, ?)";
                        PreparedStatement ps = connection.prepareStatement(sql);
                        ps.setString(1, namaProduk);
                        ps.setDouble(2, hargaProduk);
                        int result = ps.executeUpdate();
                        if (result > 0) {
                            JOptionPane.showMessageDialog(this, "Produk berhasil ditambahkan.");
                            model.setRowCount(0);
                            loadProduk();
                        } else {
                            JOptionPane.showMessageDialog(this, "Gagal menambahkan produk.");
                        }
                    }
                } else {
                    JOptionPane.showMessageDialog(this, "Harga produk tidak boleh kosong.");
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Harga produk harus berupa angka.");
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "Gagal menambahkan produk: " + e.getMessage());
            }
        }
    }
    
    private void editProdukActionPerformed(ActionEvent evt) {
        int selectedRow = table.getSelectedRow();
        if (selectedRow != -1) {
            String namaProdukBaru = JOptionPane.showInputDialog(this, "Masukkan Nama Produk Baru:", model.getValueAt(selectedRow, 1));
            if (namaProdukBaru != null && !namaProdukBaru.isEmpty()) {
                try {
                    String inputHargaBaru = JOptionPane.showInputDialog(this, "Masukkan Harga Produk Baru (tanpa titik atau koma):", model.getValueAt(selectedRow, 2));
                    if (inputHargaBaru != null && !inputHargaBaru.isEmpty()) {
                        double hargaProdukBaru = Double.parseDouble(inputHargaBaru);
                        String formattedHargaBaru = formatRupiah(hargaProdukBaru);
                        
                        int productId = (int) model.getValueAt(selectedRow, 0);
                        int confirm = JOptionPane.showConfirmDialog(this, "Anda yakin ingin mengubah produk dengan detail berikut?\n\nNama: " + namaProdukBaru + "\nHarga: " + formattedHargaBaru, "Konfirmasi", JOptionPane.YES_NO_OPTION);
                        if (confirm == JOptionPane.YES_OPTION) {
                            String sql = "UPDATE products SET product_name = ?, price = ? WHERE product_id = ?";
                            PreparedStatement ps = connection.prepareStatement(sql);
                            ps.setString(1, namaProdukBaru);
                            ps.setDouble(2, hargaProdukBaru);
                            ps.setInt(3, productId);
                            int result = ps.executeUpdate();
                            if (result > 0) {
                                JOptionPane.showMessageDialog(this, "Produk berhasil diubah.");
                                model.setRowCount(0);
                                loadProduk();
                            } else {
                                JOptionPane.showMessageDialog(this, "Gagal mengubah produk.");
                            }
                        }
                    } else {
                        JOptionPane.showMessageDialog(this, "Harga produk tidak boleh kosong.");
                    }
                } catch (NumberFormatException e) {
                    JOptionPane.showMessageDialog(this, "Harga produk harus berupa angka.");
                } catch (SQLException e) {
                    JOptionPane.showMessageDialog(this, "Gagal mengubah produk: " + e.getMessage());
                }
            }
        } else {
            JOptionPane.showMessageDialog(this, "Pilih produk yang akan diubah.");
        }
    }
    
    private void hapusProdukActionPerformed(ActionEvent evt) {
        int selectedRow = table.getSelectedRow();
        if (selectedRow != -1) {
            int confirm = JOptionPane.showConfirmDialog(this, "Apakah Anda yakin ingin menghapus produk ini?", "Konfirmasi", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                try {
                    int productId = (int) model.getValueAt(selectedRow, 0);
                    String sql = "DELETE FROM products WHERE product_id = ?";
                    PreparedStatement ps = connection.prepareStatement(sql);
                    ps.setInt(1, productId);
                    int result = ps.executeUpdate();
                    if (result > 0) {
                        JOptionPane.showMessageDialog(this, "Produk berhasil dihapus.");
                        model.removeRow(selectedRow);
                    } else {
                        JOptionPane.showMessageDialog(this, "Gagal menghapus produk.");
                    }
                } catch (SQLException e) {
                    JOptionPane.showMessageDialog(this, "Gagal menghapus produk: " + e.getMessage());
                }
            }
        } else {
            JOptionPane.showMessageDialog(this, "Pilih produk yang akan dihapus.");
        }
    }

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AdminPanel().setVisible(true);
            }
        });
    }
}
